package edu.ilstu.lai.RegistrationDemo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import edu.ilstu.lai.RegistrationDemo.entity.User;
import edu.ilstu.lai.RegistrationDemo.repository.UserRepository;

@Controller
public class AppController {

	@GetMapping("")
	public String viewHomePage() {
	return "index";
	}

	@GetMapping("/register")
	public String showRegistrationForm(Model model) {
	model.addAttribute("user", new User());

	return "signup_form";
	}

	@Autowired
	private UserRepository userRepo;


	@PostMapping("/process_register")
	public String processRegister(User user) {

	//how come userRepo can save data without any methods in it?
	userRepo.save(user);

	return "register_success";
	}

}
