package edu.ilstu.lai.RegistrationDemo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import edu.ilstu.lai.RegistrationDemo.entity.User;

public interface UserRepository extends JpaRepository<User, Long>  {

}
