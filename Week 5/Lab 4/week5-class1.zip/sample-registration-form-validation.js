function formValidate()
{
	var userId = document.registration.userid; //try var uid = document.getElementsByName("userid")[0];	
	let idValidation = idValidate(userId,5,12);

	
}	

function idValidate(userId,mx,my)
{
	
}

